ln -s ../resource . 
wget -O 'Good coding practices.ipynb' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Good%20Programming%20Practices/Good%20coding%20practices.ipynb 
cd ../resource/asnlib/public
