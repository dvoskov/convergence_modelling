ln -s ../resource . 
wget -O 'Notebook 1 Python Basics.ipynb' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%201/Notebook%201%20Python%20Basics.ipynb 
cd ../resource/asnlib/public
wget -O 'Notebook_1_anatomy_of_an_error.png' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%201/resource/asnlib/public/Notebook_1_anatomy_of_an_error.png 
wget -O 'Notebook_1_behind_the_scenes.png' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%201/resource/asnlib/public/Notebook_1_behind_the_scenes.png 
wget -O 'Notebook_1_stop_button.png' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%201/resource/asnlib/public/Notebook_1_stop_button.png 
wget -O 'Notebook_1_restartkernelmenu.png' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%201/resource/asnlib/public/Notebook_1_restartkernelmenu.png 
