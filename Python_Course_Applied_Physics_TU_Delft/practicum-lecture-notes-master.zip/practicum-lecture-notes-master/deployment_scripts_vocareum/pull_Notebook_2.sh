ln -s ../resource . 
wget -O 'Notebook 2 Functions.ipynb' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%202/Notebook%202%20Functions.ipynb 
cd ../resource/asnlib/public
