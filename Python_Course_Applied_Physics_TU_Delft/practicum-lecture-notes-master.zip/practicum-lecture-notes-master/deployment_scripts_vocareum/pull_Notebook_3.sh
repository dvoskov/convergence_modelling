ln -s ../resource . 
wget -O 'Notebook 3 Program Flow Control.ipynb' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%203/Notebook%203%20Program%20Flow%20Control.ipynb 
cd ../resource/asnlib/public
