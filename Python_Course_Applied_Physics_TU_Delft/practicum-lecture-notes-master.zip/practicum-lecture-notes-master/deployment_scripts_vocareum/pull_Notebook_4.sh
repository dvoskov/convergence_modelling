ln -s ../resource . 
wget -O 'Notebook 4 Scientific Computing with Numpy.ipynb' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%204/Notebook%204%20Scientific%20Computing%20with%20Numpy.ipynb 
cd ../resource/asnlib/public
