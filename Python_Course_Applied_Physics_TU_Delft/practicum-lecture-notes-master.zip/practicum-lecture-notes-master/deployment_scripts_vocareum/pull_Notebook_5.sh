ln -s ../resource . 
wget -O 'Notebook 5 Data in Python.ipynb' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%205/Notebook%205%20Data%20in%20Python.ipynb 
cd ../resource/asnlib/public
wget -O 'v_vs_time.dat' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%205/resource/asnlib/public/v_vs_time.dat 
wget -O 'exercise_data.dat' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%205/resource/asnlib/public/exercise_data.dat 
wget -O 'example2.dat' https://gitlab.tudelft.nl/python-for-applied-physics/practicum-lecture-notes/-/raw/master/Notebook%205/resource/asnlib/public/example2.dat 
